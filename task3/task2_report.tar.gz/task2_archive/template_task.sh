#!/bin/bash
script_name=$(basename "$0")
log_file="report_${script_name}.log"
if [[ "$script_name" == "template_task.sh" ]]; then
 echo "я бригадир, сам не работаю"
 exit 1
fi
echo "[$$] $(date '+%F %T') Скрипт запущен" >> "$log_file"
sleep_time=$((RANDOM % (1800 - 30 + 1) + 30))
sleep "$sleep_time" 
minutes=$((sleep_time / 60))
echo "[$$] $(date '+%F %T') Скрипт завершился, работал $minutes минут" >> "$log_file"
