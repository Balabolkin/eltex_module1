#!/bin/bash
conf_file="observer.conf"
log_file="observer.log"
while read -r script; do
 script_base=$(basename "$script")
 if ! pgrep -f "$script_base" > /dev/null; then
    nohup "$script" > /dev/null 2>&1 & 
    echo "[$$] $(date '+%F %T') Перезапуск $script_base" >> "$log_file" 
 fi
done < "$conf_file"
